
(function(){
var h=document.querySelector(".hdr");function sc(){h.classList.toggle("sc",scrollY>20)}addEventListener("scroll",sc,{passive:true});sc();
var dr=document.querySelector(".drawer");document.querySelectorAll("[data-drawer]").forEach(function(b){b.addEventListener("click",function(){dr.classList.toggle("on");document.body.style.overflow=dr.classList.contains("on")?"hidden":""})});
dr.querySelectorAll("a").forEach(function(a){a.addEventListener("click",function(){dr.classList.remove("on");document.body.style.overflow=""})});
var red=matchMedia("(prefers-reduced-motion: reduce)").matches;
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add("in");io.unobserve(e.target)}})},{threshold:.12});
document.querySelectorAll(".rv").forEach(function(el){io.observe(el)});
var rot=document.querySelector(".rot");if(rot&&!red){var ws=JSON.parse(rot.dataset.w),i=0;setInterval(function(){rot.classList.add("out");setTimeout(function(){i=(i+1)%ws.length;rot.textContent=ws[i];rot.classList.remove("out")},350)},2600)}
document.querySelectorAll("[data-tabs]").forEach(function(g){var bs=g.querySelectorAll("[data-t]");bs.forEach(function(b){b.addEventListener("click",function(e){e.preventDefault();bs.forEach(function(x){x.classList.toggle("on",x===b)});
 document.querySelectorAll('[data-tp="'+g.dataset.tabs+'"]').forEach(function(p){p.classList.toggle("on",p.dataset.id===b.dataset.t)})})})});
document.querySelectorAll("[data-count]").forEach(function(el){var to=+el.dataset.count,dec=+(el.dataset.dec||0);var o=new IntersectionObserver(function(es){if(!es[0].isIntersecting)return;o.disconnect();var t0=null;
 function f(t){if(!t0)t0=t;var p=Math.min(1,(t-t0)/1200);el.textContent=(to*p).toLocaleString("en-US",{minimumFractionDigits:dec,maximumFractionDigits:dec});if(p<1)requestAnimationFrame(f)}red?el.textContent=to.toLocaleString("en-US"):requestAnimationFrame(f)});o.observe(el)});
var tk=document.querySelectorAll("[data-tick]");if(!red)setInterval(function(){tk.forEach(function(el){var v=+el.textContent.replace(/,/g,"");v+=Math.round(Math.random()*3);el.textContent=v.toLocaleString("en-US")})},2200);
var est=document.getElementById("est");if(est){var q=function(n){return +est.querySelector('[name='+n+']').value},fmt=function(v){return Math.round(v).toLocaleString("en-US")};
 function calc(){est.querySelectorAll("input[type=range]").forEach(function(r){var o=est.querySelector('output[for='+r.name+']');if(o)o.textContent=(+r.value).toLocaleString("en-US")});
  var fuel=q("v")*q("km")*12*q("lp")/100*q("fp"),idle=q("v")*q("ih")*26*12*1.5*q("fp"),mnt=q("v")*q("mt")*12,tot=fuel+idle+mnt,sav=fuel*q("fi")/100+idle*q("ir")/100;
  est.querySelector("[data-o=tot]").textContent=fmt(tot);est.querySelector("[data-o=fuel]").textContent=fmt(fuel);est.querySelector("[data-o=idle]").textContent=fmt(idle);est.querySelector("[data-o=mnt]").textContent=fmt(mnt);est.querySelector("[data-o=sav]").textContent=fmt(sav)}
 est.addEventListener("input",calc);calc()}
var f=document.getElementById("lead");if(f)f.addEventListener("submit",function(e){e.preventDefault();var d=new FormData(f),L=f.dataset.lang==="ar",lines=[];
 f.querySelectorAll("[name]").forEach(function(el){var v=(d.get(el.name)||"").toString().trim();if(v)lines.push(el.dataset.l+": "+v)});
 var msg=(L?"طلب عرض سعر من الموقع":"Quote request from the website")+"\n"+lines.join("\n");window.open("https://wa.me/966542043869?text="+encodeURIComponent(msg),"_blank","noopener");location.href=f.dataset.thanks});
var mapEl=document.getElementById("map");if(mapEl&&window.maplibregl){try{var m=new maplibregl.Map({container:mapEl,style:"https://tiles.openfreemap.org/styles/positron",center:[46.6753,24.7136],zoom:11.2,interactive:false,attributionControl:{compact:true}});
 m.on("load",function(){var pts=[[46.62,24.74],[46.70,24.69],[46.74,24.76],[46.66,24.66],[46.79,24.72],[46.58,24.70]];pts.forEach(function(p,i){var el=document.createElement("div");el.style.cssText="width:14px;height:14px;border-radius:50%;background:"+(i%3?"#1f6bff":"#F99E4B")+";box-shadow:0 0 0 6px rgba(31,107,255,.18);border:2px solid #fff";new maplibregl.Marker({element:el}).setLngLat(p).addTo(m)});
 if(!red){var a=0;(function spin(){a+=0.02;m.setBearing(Math.sin(a/20)*8);requestAnimationFrame(spin)})()}});document.querySelector(".mapfb").remove()}catch(e){}}
})();
