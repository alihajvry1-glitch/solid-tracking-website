(function(){
var ar=document.documentElement.dir==="rtl",WA="966542043869";
var K=ar?[
 [/سعر|اسعار|أسعار|تكلف|كم /,"الأسعار تعتمد على عدد المركبات ونوع الجهاز. أرسل لنا عدد مركباتك ونوعها على واتساب ونرسل لك عرض سعر واضح."],
 [/وقود|ديزل|بنزين|خزان/,"حساس مستوى الوقود يُركّب داخل الخزان ويقيس مستوى الديزل باستمرار، وينبهك عند التعبئة أو أي سحب غير معتاد، مع تقارير استهلاك لكل مركبة."],
 [/كامير|داش|تسجيل|فيديو/,"الكاميرا الذكية تسجل الطريق والمقصورة على بطاقة ذاكرة، ويمكن مراجعة الأحداث والمشاهدة عبر المنصة."],
 [/هيئة|وصل|نقل|ربط|بطاقة التشغيل/,"نساعدك في ربط مركباتك بمتطلبات الهيئة العامة للنقل ومتابعة حالة الربط، مع دعم من فريقنا خلال الإجراءات."],
 [/حرار|تبريد|مبرد|ثلاج/,"حساس الحرارة يراقب حرارة صندوق الشاحنة المبردة باستمرار وينبهك عند خروجها عن النطاق المحدد."],
 [/تركيب|فرع|فروع|مدين|موقع|رياض|جدة|دمام/,"يركّب فنيونا الأجهزة في مواقعنا داخل المملكة. أخبرنا بمدينتك على واتساب ونرتب موعد التركيب."],
 [/اشتراك|تجديد|شريح|سنوي/,"كل جهاز تتبع للمركبة يأتي مع اشتراك سنوي يشمل المنصة وشريحة البيانات، ويتجدد سنوياً لكل مركبة. نوفر أيضاً أجهزة بدون شريحة."],
 [/أصول|اصول|مقطور|حاوي|معدات/,"جهاز تتبع الأصول يعمل بالبطارية ومناسب للمقطورات والحاويات والمعدات، وبدون اشتراك سنوي."],
 [/تتبع|جهاز|gps|موقع مباشر/i,"جهاز التتبع يعطيك الموقع المباشر وسجل الرحلات وتنبيهات السرعة وتشغيل المحرك، من الجوال أو لوحة التحكم."]
]:[
 [/price|cost|how much|quote/i,"Prices depend on how many vehicles you have and the device type. Send us your vehicle count on WhatsApp and we'll reply with a clear quote."],
 [/fuel|diesel|tank/i,"The fuel level sensor sits inside the tank and measures the diesel level continuously, alerting you to refuels and unusual drops, with consumption reports per vehicle."],
 [/camera|dashcam|video|record/i,"The smart camera records the road and cabin to a memory card; you can review events and watch live through the platform."],
 [/tga|wasl|transport authority|link|operating card/i,"We help link your vehicles to Transport General Authority requirements and follow the linking status, with support from our team."],
 [/temp|cold|reefer|fridge/i,"The temperature sensor watches the refrigerated box temperature and alerts you when it leaves your set range."],
 [/install|branch|city|location|riyadh|jeddah|dammam/i,"Our technicians install the devices at our locations across the Kingdom. Tell us your city on WhatsApp and we'll book an installation."],
 [/subscri|renew|sim|yearly|annual/i,"Each vehicle tracker comes with a yearly subscription covering the platform and data SIM, renewed per vehicle. Devices without a SIM are also available."],
 [/asset|trailer|container|equipment/i,"The asset tracker is battery powered, suits trailers, containers and equipment, and has no yearly subscription."],
 [/track|gps|device|location/i,"The GPS tracker gives you live location, trip history and speed/engine alerts on mobile or the web dashboard."]
];
var T=ar?{t:"مساعد سوليد تراكينج",s:"اسأل سؤالك وسنرد عليك على واتساب",hi:"مرحباً 👋 اكتب سؤالك عن أجهزة التتبع أو الحساسات أو الربط مع هيئة النقل.",ph:"اكتب سؤالك هنا…",send:"إرسال",wa:"أرسل سؤالك على واتساب",def:"سؤال ممتاز! فريقنا سيرد عليك مباشرة على واتساب.",pre:"مرحباً سوليد تراكينج، سؤالي: ",chips:["كم السعر؟","حساس الوقود","الربط مع هيئة النقل","التركيب في مدينتي"],open:"اسألنا"}
 :{t:"Solid Tracking assistant",s:"Ask a question, we reply on WhatsApp",hi:"Hi 👋 Ask about trackers, sensors, cameras or TGA linking.",ph:"Type your question…",send:"Send",wa:"Send your question on WhatsApp",def:"Great question! Our team will answer you directly on WhatsApp.",pre:"Hi Solid Tracking, my question: ",chips:["How much does it cost?","Fuel sensor","TGA linking","Installation in my city"],open:"Ask us"};
var ICO='<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 3C6.5 3 2 6.6 2 11c0 2.4 1.3 4.6 3.4 6.1L4.6 21l4.1-2.2c1 .3 2.1.4 3.3.4 5.5 0 10-3.6 10-8.1S17.5 3 12 3zm-4 9.3a1.3 1.3 0 1 1 0-2.6 1.3 1.3 0 0 1 0 2.6zm4 0a1.3 1.3 0 1 1 0-2.6 1.3 1.3 0 0 1 0 2.6zm4 0a1.3 1.3 0 1 1 0-2.6 1.3 1.3 0 0 1 0 2.6z"/></svg>';
var WI='<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm4.5 12.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.8 11.9 11.9 0 0 0 4.6 4c1.7.7 2.4.8 3.2.7a2.8 2.8 0 0 0 1.8-1.3 2.3 2.3 0 0 0 .2-1.3c-.1-.1-.3-.2-.5-.3z"/></svg>';
var w=document.createElement("div");w.className="aiw";
w.innerHTML='<button type="button" class="aiw-btn" aria-expanded="false" aria-controls="aiwBox">'+ICO+'<span>'+T.open+'</span></button>'+
'<div class="aiw-box" id="aiwBox" role="dialog" aria-label="'+T.t+'" hidden><div class="aiw-h"><span class="aiw-av">'+ICO+'</span><div><b>'+T.t+'</b><small><i></i>'+T.s+'</small></div><button type="button" class="aiw-x" aria-label="×">×</button></div>'+
'<div class="aiw-log" aria-live="polite"></div><div class="aiw-chips">'+T.chips.map(function(c){return '<button type="button">'+c+'</button>';}).join("")+'</div>'+
'<form class="aiw-f"><input type="text" maxlength="400" placeholder="'+T.ph+'" aria-label="'+T.ph+'"><button type="submit" aria-label="'+T.send+'">➤</button></form></div>';
document.body.appendChild(w);document.body.classList.add("has-aiw");
var box=w.querySelector(".aiw-box"),log=w.querySelector(".aiw-log"),inp=w.querySelector("input"),btn=w.querySelector(".aiw-btn");
function msg(text,who){var d=document.createElement("div");d.className="aiw-m "+who;d.textContent=text;log.appendChild(d);log.scrollTop=log.scrollHeight;return d;}
function waLink(q){return "https://wa.me/"+WA+"?text="+encodeURIComponent(T.pre+q);}
function answer(q){
  var a=T.def;for(var i=0;i<K.length;i++){if(K[i][0].test(q)){a=K[i][1];break;}}
  var typing=msg("…","bot typing");
  setTimeout(function(){typing.remove();msg(a,"bot");
    var l=document.createElement("a");l.className="aiw-wa";l.href=waLink(q);l.target="_blank";l.rel="noopener";l.setAttribute("data-cta","whatsapp");l.setAttribute("data-cta-location","assistant");
    l.innerHTML=WI+T.wa;log.appendChild(l);log.scrollTop=log.scrollHeight;
    try{(window.dataLayer=window.dataLayer||[]).push({event:"assistant_question"});}catch(e){}
  },650);
}
function ask(q){q=(q||"").trim();if(!q)return;msg(q,"me");answer(q);}
function toggle(o){box.hidden=!o;btn.setAttribute("aria-expanded",o);w.classList.toggle("open",o);if(o){if(!log.childNodes.length)msg(T.hi,"bot");setTimeout(function(){inp.focus();},50);}}
btn.addEventListener("click",function(){toggle(box.hidden);});
w.querySelector(".aiw-x").addEventListener("click",function(){toggle(false);btn.focus();});
w.querySelector(".aiw-f").addEventListener("submit",function(e){e.preventDefault();ask(inp.value);inp.value="";});
w.querySelectorAll(".aiw-chips button").forEach(function(b){b.addEventListener("click",function(){ask(b.textContent);});});
document.addEventListener("keydown",function(e){if(e.key==="Escape"&&!box.hidden)toggle(false);});
})();